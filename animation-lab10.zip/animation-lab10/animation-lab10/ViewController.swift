//
//  ViewController.swift
//  animation-lab10
//
//  Created by Alex Klinger on 11/11/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var delta = CGPointMake(12,4)
    var ballRadius = CGFloat()
    var timer = NSTimer()
    var translation = CGPointMake(0, 0)
    var angle: CGFloat=0.0
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var sliderlabel: UILabel!
    
    @IBAction func sliderMoved(sender: UISlider) {
        timer.invalidate()
        changeSliderValue()
    }
    func moveImage(){
        let duration=Double(slider.value)
        UIView.beginAnimations("coffee cup", context: nil)
        UIView.animateWithDuration(duration, animations:
            {self.imageView.transform=CGAffineTransformMakeRotation(self.angle)
                self.imageView.center=CGPointMake(self.imageView.center.x + self.delta.x, self.imageView.center.y + self.delta.y)})
        
        
        UIView.commitAnimations()
        angle += 0.02
        if angle > CGFloat(2*M_PI){
            angle=0
        }
        if imageView.center.x + translation.x > self.view.bounds.size.width-ballRadius || imageView.center.x + translation.x < ballRadius{
            delta.x = -delta.x
        }
        if imageView.center.y + translation.y > self.view.bounds.size.width-ballRadius || imageView.center.y + translation.y < ballRadius{
            delta.y = -delta.x
        }
    }
        //updates time and label with slider value
    @IBAction func changeSliderValue() {
        sliderlabel.text=String(format: "%.2f", slider.value)
        timer=NSTimer.scheduledTimerWithTimeInterval(Double(slider.value), target: self, selector: "moveImage", userInfo: nil, repeats: true)
    }
    
    override func viewDidLoad() {
        ballRadius=imageView.frame.size.width/2
        changeSliderValue()
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

