//
//  dataManager.swift
//  task-lab13
//
//  Created by Alex Klinger on 11/20/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import Foundation

class dataManager {
    
    var path = []
    
    func docFilePath(filename: String)->String? {
        
        let paths = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentationDirectory, NSSearchPathDomainMask.AllDomainsMask, true)
        
        let dir = paths[0] as String
        return dir.stringByAppendingPathComponent(filename)
    }
}