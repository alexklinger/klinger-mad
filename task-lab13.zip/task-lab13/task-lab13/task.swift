//
//  task.swift
//  task-lab13
//
//  Created by Alex Klinger on 11/20/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import Foundation

class Task : NSObject, NSCoding {
    var tasks = NSMutableArray()


    override init(){
        super.init()
    }
   
    func encodeWithCoder(aCoder: NSCoder){
        aCoder.encodeObject(tasks[0], forKey: "taskOneField")
        aCoder.encodeObject(tasks[1], forKey: "taskTwoField")
        aCoder.encodeObject(tasks[2], forKey: "taskThreeField")
        aCoder.encodeObject(tasks[3], forKey: "taskFourField")
        
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init()
        tasks[0] = aDecoder.decodeObjectForKey("taskOneField")!
        tasks[1] = aDecoder.decodeObjectForKey("taskTwoField")!
        tasks[2] = aDecoder.decodeObjectForKey("taskThreeField")!
        tasks[3] = aDecoder.decodeObjectForKey("taskFourField")!

    }

}