//
//  ViewController.swift
//  task-lab13
//
//  Created by Alex Klinger on 11/20/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let kFilename = "data.plist"
    var dataFilePath = dataManager()
    var taskArchive = Task()
    
    @IBOutlet weak var taskOneField: UITextField!
    @IBOutlet weak var taskTwoField: UITextField!
    @IBOutlet weak var taskThreeField: UITextField!
    @IBOutlet weak var taskFourField: UITextField!
    
    
    override func viewDidLoad() {
        let filepath = dataFilePath.docFilePath(kFilename)
        let fileManger = NSFileManager.defaultManager()
        if fileManger.fileExistsAtPath(filepath!){
            let data = NSData(contentsOfFile: filepath!)
            let unarchiver = NSKeyedUnarchiver(forReadingWithData: data!)
            taskArchive = unarchiver.decodeObjectForKey("data") as Task
            unarchiver.finishDecoding()
            
            taskOneField.text=taskArchive.tasks[0] as String
            taskTwoField.text=taskArchive.tasks[1] as String
            taskThreeField.text=taskArchive.tasks[2] as String
            taskFourField.text=taskArchive.tasks[3] as String
        
            
        }
        let app = UIApplication.sharedApplication()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "applicationWillResignActive:", name: "UIApplicationWillResignActiveNotification", object: app)
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func applicationWillResignActive(notification: NSNotification){
        let filepath = dataFilePath.docFilePath(kFilename)
        var data = NSMutableArray()
        taskArchive.tasks[0]=taskOneField.text
        taskArchive.tasks[1]=taskTwoField.text
        taskArchive.tasks[2]=taskThreeField.text
        taskArchive.tasks[3]=taskFourField.text
        var data2 = NSMutableData()
        let archiver = NSKeyedArchiver(forWritingWithMutableData: data2)
        
        archiver.encodeObject(taskArchive, forKey: "Data")
        archiver.finishEncoding()
        
        
        data.writeToFile(filepath!, atomically: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

