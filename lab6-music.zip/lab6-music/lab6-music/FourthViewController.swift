//
//  FourthViewController.swift
//  lab6-music
//
//  Created by Alex Klinger on 10/16/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {

    @IBOutlet weak var artistPicker: UIPickerView!
    @IBOutlet weak var artistLabel: UILabel!






    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
