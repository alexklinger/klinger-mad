//
//  ViewController.swift
//  proj1congress
//
//  Created by Alex Klinger on 10/2/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate{

    @IBOutlet weak var userZip: UITextField!
    @IBOutlet weak var repDisplay: UILabel!
    
    
    func textFieldShouldReturn(textField: UITextField!) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    
    func checkZip(){
        let path = NSBundle.mainBundle().pathForResource("coloradocongress", ofType: "plist")
        let dict = NSDictionary(contentsOfFile: path!)!
        let currentZip = userZip.text
    
        //println(dict)
        
        
            for (congressmen, zipCodes) in dict{
            for zip in zipCodes as [AnyObject] {
                if zip as NSString == currentZip{
                    
                    repDisplay.text = congressmen as? String
                    
                }
            }
        
        }
    
    }
    
    func textFieldDidEndEditing(textField: UITextField!) {
        checkZip()
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "contactSegue"){
            var congressVC=segue.destinationViewController as ContactViewController
            congressVC.myStorage.congressSelect=repDisplay.text
        }
    }
    
    override func viewDidLoad() {
       userZip.delegate=self
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

