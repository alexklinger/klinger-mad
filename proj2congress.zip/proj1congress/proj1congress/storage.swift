//
//  storage.swift
//  proj1congress
//
//  Created by Alex Klinger on 11/12/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import Foundation

class Storage {
    var congressSelect: String?
    
    init(){
        congressSelect=nil
    }
}