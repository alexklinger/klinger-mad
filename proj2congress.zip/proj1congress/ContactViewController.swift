//
//  ContactViewController.swift
//  proj1congress
//
//  Created by Alex Klinger on 11/12/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import UIKit

class ContactViewController: UIViewController {
    var myStorage = Storage()
    
    let perlmutterPhone = "tel://3032747944"
    let perlmutterEmail = "mailto:Perlmutter@mail.house.gov"
    let coffmanPhone = "tel://7207487514"
    let coffmanEmail = "mailto:coffman@mail.house.gov"
    let lambornPhone = "tel://7195200055"
    let lambornEmail = "mailto:lamborn@mail.house.gov"
    let gardnerPhone = "tel://7205083937"
    let gardnerEmail = "mailto:gardner@mail.house.gov"
    let tiptonPhone = "tel://9702591490"
    let tiptonEmail = "mailto:tipton@mail.house.gov"
    let polisPhone = "tel://3034849596"
    let polisEmail = "mailto:polis@mail.house.gov"
    let degettePhone = "tel://3038444988"
    let degetteEmail = "mailto:degette@mail.house.gov"
    
    
    @IBAction func emailButton(sender: AnyObject) {
       
        //println(myStorage.congressSelect)
        
        if myStorage.congressSelect! == "Ed Perlmutter"{
            
            let perlmutterurl:NSURL = NSURL(string:perlmutterEmail)!
            UIApplication.sharedApplication().openURL(perlmutterurl)
            
        }
        if myStorage.congressSelect! == "Mike Coffman"{
            
            let coffmanurl:NSURL = NSURL(string:coffmanEmail)!
            UIApplication.sharedApplication().openURL(coffmanurl)
            
        }
        if myStorage.congressSelect! == "Doug Lamborn"{
            
            let lambornurl:NSURL = NSURL(string:lambornEmail)!
            UIApplication.sharedApplication().openURL(lambornurl)
            
        }
        if myStorage.congressSelect! == "Cory Gardner"{
            
            let gardnerurl:NSURL = NSURL(string:gardnerEmail)!
            UIApplication.sharedApplication().openURL(gardnerurl)
            
        }
        if myStorage.congressSelect! == "Scott Tipton"{
            
            let tiptonurl:NSURL = NSURL(string:tiptonEmail)!
            UIApplication.sharedApplication().openURL(tiptonurl)
            
        }
        
        if myStorage.congressSelect! == "Jared Polis"{
            
            let polisurl:NSURL = NSURL(string:polisEmail)!
            UIApplication.sharedApplication().openURL(polisurl)
            
        }
        if myStorage.congressSelect! == "Diana DeGette"{
            
            let degetteurl:NSURL = NSURL(string:degetteEmail)!
            UIApplication.sharedApplication().openURL(degetteurl)
            
        }
        
        
    }

    
    @IBAction func callButton(sender: AnyObject) {

        if myStorage.congressSelect! == "Ed Perlmutter"{
            let perlmutterphoneurl:NSURL = NSURL(string:perlmutterPhone)!
            UIApplication.sharedApplication().openURL(perlmutterphoneurl)
        }
        if myStorage.congressSelect! == "Mike Coffman"{
            let coffmanphoneurl:NSURL = NSURL(string:coffmanPhone)!
            UIApplication.sharedApplication().openURL(coffmanphoneurl)
        }
        if myStorage.congressSelect! == "Doug Lamborn"{
            let lambornphoneurl:NSURL = NSURL(string:lambornPhone)!
            UIApplication.sharedApplication().openURL(lambornphoneurl)
        }
        if myStorage.congressSelect! == "Cory Gardner"{
            let gardnerphoneurl:NSURL = NSURL(string:gardnerPhone)!
            UIApplication.sharedApplication().openURL(gardnerphoneurl)
        }
        if myStorage.congressSelect! == "Scott Tipton"{
            let tiptonphoneurl:NSURL = NSURL(string:tiptonPhone)!
            UIApplication.sharedApplication().openURL(tiptonphoneurl)
        }
        
        if myStorage.congressSelect! == "Jared Polis"{
            let polisphoneurl:NSURL = NSURL(string:polisPhone)!
            UIApplication.sharedApplication().openURL(polisphoneurl)
        }
        if myStorage.congressSelect! == "Diana DeGette"{
            let degettephoneurl:NSURL = NSURL(string:degettePhone)!
            UIApplication.sharedApplication().openURL(degettephoneurl)

        }

        
    }
    

    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
