
//
//  Favorite.swift
//  lab5
//
//  Created by Alex Klinger on 10/11/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import Foundation

class Favorite {
    var favBook : String?
    var favAuthor : String?


init(){
    favBook=nil
    favAuthor=nil
}

}