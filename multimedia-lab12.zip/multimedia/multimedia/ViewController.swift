//
//  ViewController.swift
//  multimedia
//
//  Created by Alex Klinger on 11/18/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import UIKit
import MobileCoreServices

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    
    var image: UIImage?
    
    @IBAction func cameraButton(sender: UIBarButtonItem) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera){
            var imagePickerController=UIImagePickerController()
            imagePickerController.delegate=self
            imagePickerController.sourceType=UIImagePickerControllerSourceType.Camera
            imagePickerController.mediaTypes=[kUTTypeImage]
            self.presentViewController(imagePickerController, animated: true, completion: nil)
        }
        else {
            
        println("can't access camera")
        }
    }
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [NSObject : AnyObject]) {
        let mediaType = info[UIImagePickerControllerMediaType] as String
        if mediaType == kUTTypeImage{
            image = info[UIImagePickerControllerOriginalImage] as? UIImage
            imageView.image=image
        }
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func actionButton(sender: UIBarButtonItem) {
        let actionSheet = UIAlertController(title: "Media Action", message: "What would you like to do with you media?", preferredStyle: UIAlertControllerStyle.ActionSheet)
        let roll=UIAlertAction(title: "Camera Roll", style: UIAlertActionStyle.Default, handler: {
            action in
            var imagePickerController=UIImagePickerController()
            imagePickerController.delegate=self
            imagePickerController.sourceType=UIImagePickerControllerSourceType.SavedPhotosAlbum
            imagePickerController.mediaTypes=UIImagePickerController.availableMediaTypesForSourceType(.SavedPhotosAlbum)!
            self.presentViewController(imagePickerController, animated: true, completion: nil)
            })
                actionSheet.addAction(roll)
                let cancel=UIAlertAction(title: "cancel", style: UIAlertActionStyle.Cancel, handler: nil)
                    actionSheet.addAction(cancel)
            if (image != nil) {
            let save=UIAlertAction(title: "Save", style: UIAlertActionStyle.Default, handler: {
                action in UIImageWriteToSavedPhotosAlbum(self.image, self, Selector("image:didFinishSavingWithError:contextInfo:"), nil)
                
                })
            actionSheet.addAction(save)
        }
        presentViewController(actionSheet, animated: true, completion: nil)
    }
    
    
    func image(image:AnyObject, didFinishSaveWithError error: NSError?, contextInfo: UnsafePointer<Void>) {
        if let saveError=error{
            let errorAlert=UIAlertController(title: "Error", message:saveError.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
            let cancelAction = UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil)
            errorAlert.addAction(cancelAction)
            presentViewController(errorAlert, animated: true, completion: nil)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

