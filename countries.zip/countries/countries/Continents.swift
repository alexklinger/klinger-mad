//
//  Continents.swift
//  countries
//
//  Created by Aileen Pierce on 10/21/14.
//  Copyright (c) 2014 Aileen Pierce. All rights reserved.
//

import Foundation

class Continents {
    var continentData = NSMutableDictionary()
    var continents = [String]()
}