//
//  ViewController.swift
//  Project3
//
//  Created by Alex Klinger on 12/14/14.
//  Copyright (c) 2014 Alex Klinger. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    var chainzSound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("2chainz_yeah2", ofType: "mp3")!)
    var chainzPlayer = AVAudioPlayer()
    
    var gucciSound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("gucci_14", ofType: "mp3")!)
    var gucciPlayer = AVAudioPlayer()
    
    var jaySound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("jayz_9", ofType: "mp3")!)
    var jayPlayer = AVAudioPlayer()
    
    var kanyeSound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("haan", ofType: "wav")!)
    var kanyePlayer = AVAudioPlayer()
    
    var keefSound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("keef_bang", ofType: "mp3")!)
    var keefPlayer = AVAudioPlayer()
    
    var rossSound = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("ross_1", ofType: "mp3")!)
    var rossPlayer = AVAudioPlayer()

    @IBAction func chainz(sender: UIButton) {
        chainzPlayer.play()
    }
    
    @IBAction func gucci(sender: UIButton) {
        gucciPlayer.play()
    }
    @IBAction func jay(sender: UIButton) {
        jayPlayer.play()
    }
    @IBAction func kanye(sender: UIButton) {
        kanyePlayer.play()
    }
    @IBAction func keef(sender: UIButton) {
        keefPlayer.play()
    }
    @IBAction func ross(sender: UIButton) {
        rossPlayer.play()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        chainzPlayer = AVAudioPlayer(contentsOfURL: chainzSound, error: nil)
        chainzPlayer.prepareToPlay()

        gucciPlayer = AVAudioPlayer(contentsOfURL: gucciSound, error: nil)
        gucciPlayer.prepareToPlay()
        
        jayPlayer = AVAudioPlayer(contentsOfURL: jaySound, error: nil)
        jayPlayer.prepareToPlay()
        
        kanyePlayer = AVAudioPlayer(contentsOfURL: kanyeSound, error: nil)
        kanyePlayer.prepareToPlay()
        
        keefPlayer = AVAudioPlayer(contentsOfURL: keefSound, error: nil)
        keefPlayer.prepareToPlay()
        
        rossPlayer = AVAudioPlayer(contentsOfURL: rossSound, error: nil)
        rossPlayer.prepareToPlay()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

